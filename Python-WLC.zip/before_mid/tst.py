print("hello")
print("this is a test")
print("the 3rd line")
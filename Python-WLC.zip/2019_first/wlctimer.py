from time import time
class Timer:
    def __init__(self):
        self.start=time()
    def __del__(self):
        print("總共花了 %7.5f 秒"%(time()-self.start))